package training.assingments.methods;

public class Encapsulation {
	
	private int consid;
	private String password;
	private int adhar;
	
	public int getConsid() {
		return consid;
	}
	public void setConsid(int consid) {
		this.consid = consid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getAdhar() {
		return adhar;
	}
	public void setAdhar(int adhar) {
		this.adhar = adhar;
	}

	
}
