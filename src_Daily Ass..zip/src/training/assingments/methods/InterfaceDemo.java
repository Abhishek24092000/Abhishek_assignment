package training.assingments.methods;

interface SampleA{
	
	int price = 120;
	String name = "SampleA Demo";
	
	void area();
	void calculate();
}

interface SampleB{
	
	int price = 400;
	String name = "SampleB Demo";
	
	void area();
	void display();
}

interface C extends SampleA, SampleB{
	
}

class Demo implements C{

	@Override
	public void display() {
		System.out.println(" This is the method display");
	}

	@Override
	public void area() {
		System.out.println(" This is the method area");
	}

	@Override
	public void calculate() {
		System.out.println(" This is the method calculate");
	}
	
}

public class InterfaceDemo {

	public static void main(String[] args) {
		
		 C ob = new Demo();
         ob.area();
         ob.calculate();
         ob.display();

         SampleA sample = new Demo();
         System.out.println(sample.price + "_" + sample.name);
	}

}
