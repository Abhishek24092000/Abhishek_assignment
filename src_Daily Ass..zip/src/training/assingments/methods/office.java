package training.assingments.methods;

abstract class MNC {
    // Constructor
    MNC() {
        System.out.println("MNC Constructor: Hello");
    }
    
    // Abstract methods
    abstract void leaves();
    abstract void holidays();
    
    // Normal method
    void normalMethod() {
        System.out.println("This is a normal method from MNC");
    }
}

abstract class Infosys extends MNC {
    
    @Override
    void holidays() {
        System.out.println("Infosys holidays: 10 public holidays + 10 vacation days");
    }
}

class Hello extends Infosys {
    
    @Override
    void leaves() {
        System.out.println("Hello leaves: 12 sick leaves + 12 casual leaves per year");
    }
    
   
    @Override
    void holidays() {
        super.holidays(); 
        System.out.println("Hello adds 5 more flexible holidays");
    }
    
   
    void helloMethod() {
        System.out.println("This is Hello's special method");
    }
}

public class office {
    public static void main(String[] args) {
        // Dynamic polymorphism - Parent reference to child object
        System.out.println("Using MNC reference:");
        MNC mnc = new Hello();
        mnc.leaves();
        mnc.holidays();
        mnc.normalMethod();
        
        // Downcasting to call Hello specific method
        if (mnc instanceof Hello) {
            ((Hello)mnc).helloMethod();
        }
        
        System.out.println("\nUsing Infosys reference:");
        Infosys infosys = new Hello();
        infosys.leaves();
        infosys.holidays();
        infosys.normalMethod();
    }
}