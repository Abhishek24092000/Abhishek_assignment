package training.assingments.methods;

abstract class Customer{
	
	Customer(){
		System.out.println("This is the constructor of the Customer");
	}
	
	public void details(){
		System.out.println("This is non-abstract method of the customer class");
	}
	
	abstract public void purchase();
	abstract public void sell();
}

abstract class Employee1 extends Customer{

	abstract public void purchase();
	abstract public void sell();
	abstract public void leaves();  // created in this child class
}

abstract class Retailer extends Customer{
	
	abstract public void purchase();
	
	public void sell(){
		System.out.println("Reatiler is goign to sell the product");
	}
}

class Person extends Retailer{

	public void purchase() {
		System.out.println("The person  is goign to purchase the product");
	}
}

class Sample extends Employee1{

	@Override
	public void purchase() {
		System.out.println("Method 1 ");
		
	}

	@Override
	public void sell() {
		System.out.println("Method 2");
		
	}

	@Override
	public void leaves() {
		System.out.println("Method 3");
		
	}
}



public class CustomerDetails {

	public static void main(String[] args) {
		
		Customer cust = new Person();
		cust.sell();
		cust.purchase();
		cust.details();
		
		Employee1 c1 = new Sample();
		c1.sell();
		c1.purchase();
		c1.leaves();

	}

}
