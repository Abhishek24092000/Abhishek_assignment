package training.assingments.methods;

interface loginE {
    int empid = 120;
    String name = "Name";
    
    void register();  // Corrected spelling from 'regiter'
    void login();
}

interface cart {
    int price = 400;
    String item = "Rice";
    
    void payment();
    void wallet();
}

interface dashboard {
    int Amount = 400;
    String Itemscol = "Rice";
    
    void register();
    void profile();
}

interface b extends loginE, cart, dashboard {
    // This interface combines all methods from parent interfaces
}

class Ecommerce implements b {
    @Override
    public void register() {  // Implements register() from loginE and dashboard
        System.out.println("Registration method");
    }

    @Override
    public void login() {
        System.out.println("Login method");
    }

    @Override
    public void payment() {
        System.out.println("Payment method");
    }

    @Override
    public void wallet() {
        System.out.println("Wallet method");
    }

    @Override
    public void profile() {
        System.out.println("Profile method");
    }
}

public class Website {
    public static void main(String[] args) {
        Ecommerce ob = new Ecommerce();
        ob.register();
        ob.login();
        ob.payment();
        ob.wallet();
        ob.profile();

        // Accessing interface constants
        System.out.println(loginE.name + "_" + cart.price);
    }
}