package training.assingments.methods;

public class StringBufferDemo {

	public static void main(String[] args) {
		
		// 1. Create a StringBuffer
        StringBuffer sb = new StringBuffer("Hello");
        
        // 2. Basic operations
        System.out.println("Original: " + sb);
        System.out.println("Length: " + sb.length());
        System.out.println("Capacity: " + sb.capacity());
        
        // 3. Append operations
        sb.append(" World");
        System.out.println("\nAfter append: " + sb);
        
        // 4. Insert operations
        sb.insert(5, " Java");
        System.out.println("After insert: " + sb);
        
        // 5. Replace operations
        sb.replace(6, 10, "Programming");
        System.out.println("After replace: " + sb);
        
        // 6. Delete operations
        sb.delete(6, 17);
        System.out.println("After delete: " + sb);
        
        // 7. Reverse operation
        sb.reverse();
        System.out.println("After reverse: " + sb);
        
        // 8. Other useful methods
        sb.reverse(); // Reverse back to original order
        System.out.println("\nFinal string: " + sb);
        System.out.println("Character at index 4: " + sb.charAt(4));
        System.out.println("Index of 'W': " + sb.indexOf("W"));
        System.out.println("Substring: " + sb.substring(6));
        
        // 9. Set length
        sb.setLength(5);
        System.out.println("After setLength(5): " + sb);
        
        // 10. Ensure capacity
        sb.ensureCapacity(50);
        System.out.println("New capacity: " + sb.capacity());
    }
}

