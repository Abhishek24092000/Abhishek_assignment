package training.assingments.methods;

public class StringDemo {

	public static void main(String[] args) {
		
		String s1 = "Java";
		String s2 = " Language";
		
		s1 = s1.concat(s2);
		System.out.println("The is the string: "+ s1);
		
		s2 = s1+s2;
		System.out.println("The is the 2nd string: "+ s2 + " " + s1);;


		
		String c1 = "Java";
		String c2 = new String("Python");
		String c3 = "Java";
		String c4 = "Java";
		String c5 = new String("Python");
		
		
		if (c1.equals(c2))
		{
			System.out.println("They have the same content");
		}
		else {
			System.out.println("Not same content");
		}
		if (c1 == c2) 
		{
			System.out.println("They have the same adress");
		}
		else {
			System.out.println("They does not have the same adress");
		}
	}

}
