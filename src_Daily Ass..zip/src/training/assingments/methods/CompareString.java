package training.assingments.methods;



public class CompareString {

	public static void main(String[] args) {
	
		// String pool objects
        String t = "Delhi";    // 1st string pool object
        String o = "Mumbai";  // 2nd string pool object
        String k = "delhi";    // 3rd string pool object
        
        // Heap objects (that may also reference string pool)
        String y = new String("Mumbai");   // 1st heap object (reuses "Mumbai" from pool)
        String l = new String("delhi");    // 2nd heap object (reuses "delhi" from pool)
        String p = new String("Hello");   // 3rd heap object and 4th string pool object ("Hello")

        // Print object counts
        System.out.println("Objects in string pool: 4 (Delhi, Mumbai, delhi, Hello)");
        System.out.println("Objects in heap: 3 (from new String operations)");
        System.out.println();

        // Comparisons
        System.out.println("1. o with l:");
        System.out.println("   o.equals(l): " + o.equals(l));  // false
        System.out.println("   o == l: " + (o == l));         // false
        System.out.println();

        System.out.println("2. y with p:");
        System.out.println("   y.equals(p): " + y.equals(p));  // false
        System.out.println("   y == p: " + (y == p));          // false
        System.out.println();

        System.out.println("3. t with o:");
        System.out.println("   t.equals(o): " + t.equals(o));  // false
        System.out.println("   t == o: " + (t == o));           // false
        System.out.println();

        System.out.println("4. k with y:");
        System.out.println("   k.equals(y): " + k.equals(y));  // false
        System.out.println("   k == y: " + (k == y));          // false
        System.out.println();

        System.out.println("5. p with y:");
        System.out.println("   p.equals(y): " + p.equals(y));  // false
        System.out.println("   p == y: " + (p == y));          // false
    }
}

